/*************************** Network Config page *******************************
This file is part of the Ewings Esp Stack.

This is free software. you can redistribute it and/or modify it but without any
warranty.

Author          : Suraj I.
created Date    : 1st June 2019
******************************************************************************/
#ifndef _NETWORK_CONFIG_H_
#define _NETWORK_CONFIG_H_

#include "Common.h"

/**
 * network configurations for device communication
 */

#endif
