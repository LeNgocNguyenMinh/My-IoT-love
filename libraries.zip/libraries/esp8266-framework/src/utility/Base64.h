#ifndef _BASE64_H_
#define _BASE64_H_

#include <Arduino.h>

bool base64Encode(char input_str[], int len_str, char *res_str );

#endif
